import pandas as pd

calls_df, = pd.read_html("chatfree.herokuapp.com", header=0, parse_dates=[":Chat Server v.1"])

print(calls_df.to_json(orient="records", date_format="iso"))