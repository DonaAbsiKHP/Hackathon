# from extractEmail import extract
# from dateutil.parser import parse
import csv
from collections import Counter
from csv import DictWriter

from IPython.core.display import JSON

from exportToExcel import exportToExcel
from wordCount import freq_dist
from math import log10 as log
import base64
import os
import time
import re
import json

def extractEmail(fname):
    with open(fname, "rb") as f:
        lines = f.readlines()
        data = {}
        data["Date"] = lines[0][6:].decode("utf-8")[:-2]
        # data["datetime"] = parse(data["Date"])
        data["From"] = lines[4][6:].decode("utf-8")[:-2]
        data["To"] = lines[5][4:].decode("utf-8")[:-2]

        # try:
        index = 10
        for i in range(6, len(lines)):
            if lines[i].startswith(b"--MIME_Boundary"):
                index = i
                break
        body = []
        for i in lines[index+5:]:
            if i.startswith(b"--MIME_Boundary"): break
            body.append(i.decode("utf-8")[:-2])
        # body = [s.decode("utf-8")[:-2] for s in lines[14:-1]]
        body = "".join(body)
        body = base64.b64decode(body).decode("utf-8")
        # except Exception:
        #     print(fname)
            # print(body)
            # raise
        return data, body

def parseEmail(args):
    data, body = args
    body = re.sub("<(html|body|p|b|DIV|br)>", "", body)
    body = re.sub("</(html|body|p|b|DIV|br)>", "\n", body)
    # body = re.sub("\[\d\d\d\d\-\d\d\-\d\d \d\d:\d\d:\d\d\D\]", "", body)
    body = body.replace("<DIV style='margin-left:6.0pt'>", "").replace("Chatter [Web User] [Web User] wrote:", "")
    body = body.replace(" {0} ".format(data["From"]), "Caller")
    body = body.replace(" {0} ".format(data["To"]), "Counselor")
    body = body.replace("&quot;", "").replace(",", "").replace(".", "").replace("?", "").replace(";", "") \
                .replace(":", "").replace("&", "").replace("#", "").replace("\r", "\n")
    excludeWords = [
        "to", "a", "and", "my", "and", "the", "that", "have", "is", "are", "it", "in", "can",
        "with", "for", "do", "be", "get", "its", "so", "what", "am", "but", "has", "been", "of", "this", "or",
        "hello", "hi", "also", "as", "I'll"
    ]
    for e in excludeWords:
        body = body.replace(" {0} ".format(e), " ")
    body = re.sub("\n\n+", "\n", body)
    lines = body.split("\n")
    # for line in lines:
    #     print(line)
    # print(repr(body))
    #"Nickname",
    required = ["Gender", "Age", "Province", "Community", "Community Other"]
    conversation = [[], []]
    data["ICEID"] = ""
    for i in range(len(lines)):
        requiredFound = False
        for r in required:
            if lines[i][:len(r)] == r:
                data[r] = lines[i][len(r) + 2:]
                required.remove(r)
                requiredFound = True
                break
        if not requiredFound:
            if lines[i].startswith("Caller"):
                if lines[i+1].lower().startswith("[automated message]"):
                    data["End Time"] = lines[i][7:-2]
                    i = len(lines)
                else:
                    conversation[0].append(lines[i+1].replace("[", "").replace("]", "").replace("(", "").replace(")", ""))
                    # conversation.append(["Caller", lines[i+1]])
                    i += 1
            elif lines[i].startswith("Counselor"):
                if lines[i+1].startswith("ICEID"):
                    data["ICEID"] = lines[i+1][5:].strip()
                elif lines[i+1] != "QUEUEREADY":
                    conversation[1].append(lines[i+1])
                    # conversation.append(["Counsellor", lines[i+1]])
                i += 1

    # print(len(conversation[0]), len(conversation[1]))
    return data, conversation

def getFrequency(conversation):
    word_distribution1, sum1 = (None, 0) if not conversation[0] else freq_dist(conversation[0])
    word_distribution2, sum2 = (None, 0) #if not conversation[1] else freq_dist(conversation[1])
    return word_distribution1, sum1, word_distribution2, sum2

def speed_test():

    start = time.time()
    for i in range(100):
        # extractEmail("./20160101000207617_1_p2p.eml")
        parseEmail(extractEmail("./Test-Emails/20160101000207617_1_p2p.eml"))
        # extractEmail("./20170101000452297_1_p2p.eml")
        parseEmail(extractEmail("./Test-Emails/20170101000452297_1_p2p.eml"))
    end = time.time()
    print((end-start)*1000)

def exportEmails(test=False, path="../Data/skypearchiving.kidshelp.ca"):
    start = time.time()
    datalist = []
    directories = os.listdir(path)
    directories = [d for d in directories if d[0] != "."]
    if test:
        directories = ["test"]
    for d in directories:
        subdirectories = os.listdir(path+d)
        for sd in subdirectories:
            files = os.listdir(path+"/"+d+"/"+sd)
            for file in files:
                data, conversation = parseEmail(extractEmail(path+"/" + d + "/" + sd + "/" + file))
                data["File"] = file
                datalist.append(data)

    exportToExcel(datalist)
    end = time.time()
    print(end-start)

def exportFrequencies(test=False, path="../Data/skypearchiving.kidshelp.ca"):
    start = time.time()
    datalist = []
    directories = os.listdir(path)
    directories = [d for d in directories if d[0] != "."]
    if test:
        directories = ["test"]
    for d in directories:
        subdirectories = os.listdir(path + "/"+d)
        for sd in subdirectories:
            files = os.listdir(path + "/"+d+"/"+sd)
            for file in files:
                data, conversation = parseEmail(extractEmail(path + "/" + d + "/" + sd + "/" + file))
                wf1, s1, wf2, s2 = getFrequency(conversation)
                wf = {
                    "file":file,
                    "c0len":len(conversation[0]),
                    "c1len":len(conversation[1]),
                    "c0wf":wf1,
                    "c1wf":wf2,
                    "sum1":s1,
                    "sum2":s2
                }
                datalist.append(wf)


    with open("frequencies.txt", 'w') as f:
        f.write(json.dumps(datalist))
    # exportToExcel(datalist)

    idfs0 = {}
    for d in datalist:
        if d["c0wf"] is not None:
            for w in d["c0wf"]:
                if w in idfs0:
                    idfs0[w] += 1
                else:
                    idfs0[w] = 1
    idflist0 = []
    for w in idfs0:
        idflist0.append({"Word":w, "Count":idfs0[w]})
    with open('documentWordCount.csv', 'w') as outfile:
        writer = DictWriter(outfile, ('Word', 'Count'))
        writer.writeheader()
        writer.writerows(idflist0)

    with open('numDocuments.txt', 'w') as f:
        f.write(str(len(datalist)))

    end = time.time()
    print(end-start)

def analyseFrequencies(path):
    # start = time.time()
    # with open("frequencies.txt", 'r') as f:
    #     file = f.read()
    #     wf = json.loads(file)
    #
    # end = time.time()
    # print(end-start)

    with open("documentWordCount.csv") as f:
        idfs0 = {}
        for row in csv.DictReader(f, skipinitialspace=True):
            items = [v for k, v in row.items()]
            idfs0[items[0]] = int(items[1])
    with open('numDocuments.txt', 'r') as f:
        numDocuments = int(f.read())

    # end = time.time()
    # print(end-start)

    data, conversation = parseEmail(extractEmail(path))
    wf1, s1, wf2, s2 = getFrequency(conversation)

    numDocuments += 1

    tfidf = {}
    if wf1 is not None:
        for w in wf1:
            if w in idfs0:
                tfidf[w] = wf1[w] / s1 * log(numDocuments/(idfs0[w]+1))
            else:
                tfidf[w] = wf1[w] / s1 * log(numDocuments)

    print(Counter(tfidf).most_common(10))


    # end = time.time()
    # print(end-start)


analyseFrequencies("./Test-Emails/20170101000452297_1_p2p.eml")
# exportFrequencies(test=True)
# exportEmails(test=True)
# data, wd1, wd2 = parseEmail(extractEmail("./Test-Emails/20170101000452297_1_p2p.eml"))
# print(data)
# print()
# print(wd1)
# print()
# print(wd2)
# data, wd1, wd2 = parseEmail(extractEmail("./Test-Emails/20170101000452297_1_p2p.eml"))
# print(wd1.most_common(15))
# print(wd2.most_common(15))
# print(parseEmail(extractEmail("./Test-Emails/20170101000452297_1_p2p.eml")))
# speed_test()