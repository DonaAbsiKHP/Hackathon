import urllib.request
from collections import Counter

import numpy as np

from nltk import word_tokenize
from nltk.corpus import wordnet
from sklearn.feature_extraction.text import CountVectorizer

def freq_dist(data):
    """
    :param data: A list of sentences
    :type data: list
    """
    ngram_vectorizer = CountVectorizer(analyzer='word', tokenizer=word_tokenize, ngram_range=(1, 1), min_df=1)
    X = ngram_vectorizer.fit_transform(data)
    vocab = list(ngram_vectorizer.get_feature_names())
    counts = X.sum(axis=0).A1
    counts = [int(c) for c in counts]
    sum = int(np.sum(counts))
    v = []
    c = []
    for i, j in zip(vocab, counts):
        if wordnet.synsets(i) and len(i) > 2:
            v.append(i)
            c.append(j)
    return Counter(dict(zip(v, c))), sum



# # Note that `ngram_range=(1, 1)` means we want to extract Unigrams, i.e. tokens.
# ngram_vectorizer = CountVectorizer(analyzer='word', tokenizer=word_tokenize, ngram_range=(1, 1), min_df=1)
# # X matrix where the row represents sentences and column is our one-hot vector for each token in our vocabulary
# X = ngram_vectorizer.fit_transform(data)
#
# # Vocabulary
# vocab = list(ngram_vectorizer.get_feature_names())
#
# # Column-wise sum of the X matrix.
# # It's some crazy numpy syntax that looks horribly unpythonic
# # For details, see http://stackoverflow.com/questions/3337301/numpy-matrix-to-array
# # and http://stackoverflow.com/questions/13567345/how-to-calculate-the-sum-of-all-columns-of-a-2d-numpy-array-efficiently
# counts = X.sum(axis=0).A1
#
# freq_distribution = Counter(dict(zip(vocab, counts)))
# print (freq_distribution.most_common(20))